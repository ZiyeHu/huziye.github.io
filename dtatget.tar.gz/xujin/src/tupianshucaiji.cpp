#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include "ros/ros.h"  
#include "std_msgs/String.h"      
#include <boost/thread.hpp>  
#include "std_msgs/String.h"
#include "sensor_msgs/JointState.h"
#include<string>
#include "ros/ros.h"
#include<iostream>
#include <stdio.h>
#include <stdlib.h>
#include <thread> 
static const std::string TOPIC_NAME = "/camera/rgb/image_raw";
ros::Duration d(0.005);

void imageCallback(const sensor_msgs::ImageConstPtr& msg,std::string n) {
    const char *abc=n.data();
    cv_bridge::CvImagePtr cv_ptr = cv_bridge::toCvCopy(msg, "bgr8");
    cv::imwrite(abc, cv_ptr->image);
    d.sleep();
   
}
void jointstatesCallback(const sensor_msgs::JointStateConstPtr& msg,std::string topicName)
{
  float pos[7],vel[7];
  //pos=msg->position;
  pos[0]=msg->position[0];
  pos[1]=msg->position[1];
  pos[2]=msg->position[2];
  pos[3]=msg->position[3];
  pos[4]=msg->position[4];
  pos[5]=msg->position[5];
  pos[6]=msg->position[6];
  vel[0]=msg->velocity[0];
  vel[1]=msg->velocity[1];
  vel[2]=msg->velocity[2];
  vel[3]=msg->velocity[3];
  vel[4]=msg->velocity[4];
  vel[5]=msg->velocity[5];
  vel[6]=msg->velocity[6];
  ROS_INFO("I heard: [%f] [%f] [%f] [%f] [%f] [%f] [%f] ",pos[0],pos[1],pos[2],pos[3],pos[4],pos[5],pos[6]);
  ROS_INFO("I heard: [%f] [%f] [%f] [%f] [%f] [%f] [%f] ",vel[0],vel[1],vel[2],vel[3],vel[4],vel[5],vel[6]);
  std::cout<<pos<<std::endl;
  FILE *fp ;
  
  const char * abc=topicName.data();

  fp = fopen(abc, "w" ) ;
  for(int i=0;i<7;i++)
  {
    fprintf(fp, "%.10f", pos[i] ) ;
    fprintf( fp, "," ) ;
    
  }
   
  fprintf( fp, "\n" ) ;
  for(int i=0;i<7;i++)
  {
    fprintf(fp, "%.10f", vel[i] ) ;
    fprintf( fp, "," ) ;
    
  }
  fprintf( fp, "\n" ) ;
  fclose( fp ) ;
  d.sleep();
} 
int main(int argc, char **argv) {
    ros::init(argc, argv, "image_transport_subscriber");
    ros::NodeHandle nh;
    ros::AsyncSpinner s(600); 
    
    for(int t=1;t<500;t++)
  {
    s.start();  
    std::string f_str1=std::to_string(t);
    std::string inputstring1=f_str1+".jpg";
    std::string f_str=std::to_string(t);
    std::string inputstring=f_str+".txt";
    ros::Subscriber sub[t] = nh.subscribe<sensor_msgs::JointState>("/joint_states", 1, boost::bind(&jointstatesCallback, _1, inputstring));
    ros::Subscriber sub1[t]=nh.subscribe<sensor_msgs::Image>(TOPIC_NAME, 1,boost::bind(&imageCallback, _1, inputstring1));
    ros::Rate r(3); 
    r.sleep(); 
  }
      
  while (ros::ok())  
  {  
    ROS_INFO_STREAM("Main thread [" << boost::this_thread::get_id() << "].");  
  }
  ros::waitForShutdown();
    return 0;
}